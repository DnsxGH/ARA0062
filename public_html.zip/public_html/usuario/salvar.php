<?php
include_once "../servico/Autenticacao.php";
include_once "../servico/Bd.php";

$login=$_GET["Login"];
$senha=$_GET["senha"];

if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "update `Entrar` set login='$login', senha='$senha' where id='$id' ";
}else { //grava um novo
    $sql = "INSERT INTO `Entrar` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";    
}

$bd = new Bd();
$contador = $bd->exec($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<style>
.alert {
  padding: 20px;
  background-color: darkgrey;
  color: black;
}
</style>
</head>
<body>
<div class="alert">
  <?php echo "<h1><b>Foram armazenados/atualizados $contador registro.</b><h1>" ?>
  <a class="btn btn-primary" href="ConsultaUsuario.php" align="center">Voltar</a>
</div>

</body>
</html>
