<?php
session_start();

if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace('https://projetoshtmldavi.000webhostapp.com/3006M/login.html');
    </script>
    ";
    
}

?>