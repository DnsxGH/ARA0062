<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Dayly Hardware</title>
    <style>
        .carousel img {
    max-height: 900px;
    margin: 0 auto;
}
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
     <a class="navbar-brand" href="#"><h3>Daily Hardware</h3></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="https://projetoshtmldavi.000webhostapp.com/3006M/index.php">Home <span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <a class="btn btn-light" href="https://projetoshtmldavi.000webhostapp.com/3006M/login.html"><span class="navbar-link">
      Entrar
    </span></a>
    </div>
  </nav>
  
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="https://s.zst.com.br/cms-assets/2020/11/rtx-3080-2.jpg" alt="First slide" >
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://gamehall.com.br/wp-content/uploads/2020/10/radeon-rx-6900-xt-1.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://st.overclockers.ru/images/lab/2020/11/05/01/100_products_big.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  </div>
  <br>
    <div class="card-deck">
  <div class="card bg-dark">
    <img src="https://cdn.vox-cdn.com/thumbor/fYDzyVBZUzQb-a1nIO0QTytVkBM=/0x0:2640x1749/1200x800/filters:focal(1109x664:1531x1086)/cdn.vox-cdn.com/uploads/chorus_image/image/67381706/twarren_rtx3080.0.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title text-white">Nvidia RTX</h5>
      <p class="card-text text-white">Nvidia lançou a nova RTX 3080 em setembro deste ano por $600.</p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
  <div class="card bg-dark">
    <img src="https://imagem.avalanchenoticias.com.br/ODNmYzhkNzRiNjlmNjVlMmMzOTMzOGI3OWE0ZmExOTZhMmNkZjQwMmUwNjAyODI2YjhkYmEwYjAxNzQxYWZhZQ==.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title text-white">AMD Radeon</h5>
      <p class="card-text text-white">AMD anuncia sua nova linha de GPUs série RX 6000.</p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
  <div class="card bg-dark">
    <img src="https://www.wykop.pl/cdn/c3201142/comment_1606202794afvPsjdDKEY3w0oyJNYHej.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title text-white">AMD Ryzen</h5>
      <p class="card-text text-white">Nvidia anuncia sua nova linhas de CPUs Ryzen 5000 para Desktop.</p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>